<?php

namespace App\Model;

use Dibi\Connection;

class PagesMapper extends BaseMapper
{

	/**
	 * @param Connection $db
	 */
	public function __construct(Connection $db) {
		parent::__construct($db);
	}

	/**
	 * @param PagesEntity $page
	 * @param PagesEntity $pribuzny
	 */
	public function move(PagesEntity $page, PagesEntity $pribuzny) {
		$rozdilPage = (integer)$page->rgt() - (integer)$page->lft() + 1;
		$rozdilPribuzny = (integer)$pribuzny->rgt() - (integer)$pribuzny->lft() + 1;
		$min_lft = min($page->lft(), $pribuzny->lft());
		$max_rgt = max($page->rgt(), $pribuzny->rgt());
		switch ($page->lft() < $pribuzny->lft()) {
			case true:
				$lft = $page->lft();
				$rgt = $page->rgt();
				$rozdil = $rozdilPage;
				$posun = $rozdilPribuzny;
				break;
			case false:
			default:
				$lft = $pribuzny->lft();
				$rgt = $pribuzny->rgt();
				$rozdil = $rozdilPribuzny;
				$posun = $rozdilPage;
				break;
		}

		$sql = "" . "UPDATE pages
	        SET lft = lft + IF(@podstrom := lft >= " . $lft . " AND rgt <= " . $rgt . ", $posun, 
	                IF(lft >= " . $min_lft . ", -$rozdil, 0)),
	            rgt = rgt + IF(@podstrom, $posun, IF(rgt <= " . $max_rgt . ", -$rozdil, 0))
	        WHERE rgt >= " . $min_lft . " AND lft <= " . $max_rgt . "";

		$this->db->query($sql);
	}

	/**
	 * @param PagesEntity $page
	 * @param PagesEntity $newParent
	 */
	public function changeParent(PagesEntity $page, PagesEntity $newParent) {
		$rozdil = $page->rgt() - $page->lft() + 1;
		$lft = $newParent->rgt();
		$level = $newParent->level() + 1;
		if ($lft > $page->lft())
			$lft -= $rozdil;

		$min_lft = min($lft, $page->lft());
		$max_rgt = max($lft + $rozdil - 1, $page->rgt());
		$posun = $lft - $page->lft();
		if ($lft > $page->lft())
			$rozdil = -$rozdil;

		$sql = "" . "UPDATE $this->tableName
	        SET level = level + IF(@podstrom := lft >= " . $page->lft() . " 
	                AND rgt <= " . $page->rgt() . ", " . ($level - $page->level()) . ", 0),
	            lft = lft + IF(@podstrom, $posun, IF(lft >= $min_lft, $rozdil, 0)),
	            parent = IF(id = " . $page->id() . ", " . $newParent->id() . ", parent),
	            rgt = rgt + IF(@podstrom, $posun, IF(rgt <= $max_rgt, $rozdil, 0))
	        WHERE rgt >= $min_lft AND lft <= $max_rgt ";

		$this->db->query($sql);
	}

	/**
	 * @param PagesEntity $page
	 */
	public function prepareBeforeAdd(PagesEntity $page) {
		$sql = "" . "UPDATE $this->tableName
	        SET 
	        lft = lft + IF(lft > " . $page->rgt() . ", 2, 0),
	        rgt = rgt + IF(rgt >= " . $page->rgt() . ", 2, 0)
	         ";
		$this->db->query($sql);
	}

	/**
	 * @param PagesEntity $page
	 */
	public function prepareBeforeDelete(PagesEntity $page) {
		$sql = "" . "UPDATE $this->tableName
	        SET 
	        lft = lft - IF(lft > " . $page->rgt() . ", 2, 0),
	        rgt = rgt - IF(rgt > " . $page->rgt() . ", 2, 0)
	         ";
		$this->db->query($sql);
	}


	/**
	 * @param PagesEntity $page
	 * @return array
	 */
	public function getPosibleParentsTree(PagesEntity $page) {
		return $this->db->select('id, CONCAT(REPEAT(\'- \', level), name) as name')
			->from($this->tableName)
			->where('lft < %i OR rgt > %i', $page->lft(), $page->rgt())
			->orderBy('lft')
			->fetchPairs();
	}

	/**
	 * @param $menuType
	 * @return array
	 */
	public function getPagesInMenu($menuType) {
		return $this->db->select('id, url, name, IF(LENGTH(menuTitle) > 0, menuTitle, name) as menuTitle, '
			. 'parent, level')
			->from($this->tableName)
			->where('inMenu LIKE %~like~', $menuType)
			->where('active = %i', 1)
			->groupBy('inMenu, url')
			->orderBy('lft')
			->fetchAll();
	}

	/**
	 * @param $term
	 * @return \Dibi\Fluent
	 */
	public function search($term) {
		return $this->db->select('*')
			->from($this->tableName)
			->where("MATCH (name,title,perex,text) AGAINST ('*' %s '*' IN BOOLEAN MODE)", $term);
	}

}
