<?php
 
namespace App\AdminModule\Presenters;
 
use Grido\Components\Filters\Filter;
use Nette\Application\UI\Presenter;
use Nette\Security\User;
 
/**
 * Class BasePresenter
 * @package App\AdminModule\Presenters
 */
abstract class BasePresenter extends Presenter 
{
 
	/** @var string @persistent */
	public $filterRenderType = Filter::RENDER_INNER;
 
	/**
	 *
	 */
	protected function startup() {
		parent::startup();
		if (!$this->getUser()->isLoggedIn()) {
			if ($this->getUser()->logoutReason === User::INACTIVITY) {
				$this->flashMessage('Byli jste odhlášeni z důvodu nečinnosti. Prosím, přihlaste se znovu.');
			} else {
				$this->flashMessage('Prosím, přihlaste se.');
			}
			$this->redirect(':Front:Sign:in', ['backlink' => $this->storeRequest()]);
		}
 
		if (!$this->getUser()->isInRole('admin')) {
			$this->flashMessage('Nemáte oprávnění');
			$this->redirect(':Front:Sign:in', ['backlink' => $this->storeRequest()]);
		}
	}
 
}