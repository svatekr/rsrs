<?php

namespace App\FrontModule\Controls;

use App\Model\GalleriesRepository;
use App\Model\PagesEntity;
use Nette\Application\UI;

class GalleriesControl extends UI\Control
{

	/** @var GalleriesRepository */
	private $galleriesRepository;

	/** @var PagesEntity */
	private $page;

	/**
	 * @param PagesRepository $galleriesRepository
	 */
	public function __construct(GalleriesRepository $galleriesRepository) {
		parent::__construct();
		$this->galleriesRepository = $galleriesRepository;
	}

	/**
	 * @param $page
	 */
	public function setPage(PagesEntity $page) {
		$this->page = $page;
	}

	/**
	 *
	 */
	public function render() {
		$this->getTemplate()->galleries = $this->galleriesRepository->getAllGalleriesWithPicturesForPage($this->page);
		$this->getTemplate()->setFile(__DIR__ . '/GalleriesControl.latte');
		$this->getTemplate()->render();
	}


}
