$(function(){

    //init nette ajax
    $.nette.init();

    $(document).ready(function() {
	    $(".select2").select2();
    });

});

