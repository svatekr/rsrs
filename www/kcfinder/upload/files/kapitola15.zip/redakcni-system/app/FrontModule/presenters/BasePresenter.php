<?php

namespace App\FrontModule\Presenters;

use Nette;
use Nette\Mail\SmtpMailer;

abstract class BasePresenter extends Nette\Application\UI\Presenter
{

    /** @persistent */
    public $backlink = '';

	/**
	 * @return SendmailMailer
	 */
	protected function setMailer() {
		/** @var SmtpMailer mailer */
		$mailer = new SmtpMailer([
			'host' => 'smtpServer',
			'username' => 'smtpUsername',
			'password' => 'smtpPassword',
			'secure' => 'smtpSecure',
		]);
		return $mailer;
	}

}
