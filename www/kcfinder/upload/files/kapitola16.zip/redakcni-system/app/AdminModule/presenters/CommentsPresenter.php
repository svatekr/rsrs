<?php

namespace App\AdminModule\Presenters;

use App\Model\CommentsRepository;
use Grido\Grid;
use Nette\Utils\Html;
use Nette\Utils\Strings;

/**
 * Class CommentsPresenter
 * @package App\AdminModule\Presenters
 */
class CommentsPresenter extends BasePresenter
{

	/** @var CommentsRepository @inject */
	public $commentsRepository;

	/**
	 * Inicializace třídních proměnných
	 */
	public function startup() {
		parent::startup();
	}

	/**
	 * @param $id
	 */
	public function handleDelete($id) {
		$this->commentsRepository->delete($id);
		$this->flashMessage('Komentář byl smazán.', 'success');
		if (!$this->isAjax())
			$this->redirect('default');
		$this->redrawControl();
	}

	/**
	 * @param $id
	 */
	public function handleAllowed($id) {
		$comment = $this->commentsRepository->get($id);
		$comment->allowed(!$comment->allowed());
		$this->commentsRepository->save($comment);
		if (!$this->isAjax())
			$this->redirect('default');
		$this->redrawControl();
	}

	/**
	 * @param $name
	 * @return Grid
	 * @throws \Grido\Exception
	 */
	protected function createComponentGrid($name) {
		$grid = new Grid($this, $name);
		$grid->translator->lang = 'cs';

		$fluent = $this->commentsRepository->getAllComments();
		$grid->model = $fluent;

		$grid->addColumnText('author', 'Autor')
				->setSortable()
				->setFilterText();

		$grid->addColumnDate('date', 'Datum')
				->setSortable()
				->setFilterText();

		$grid->addColumnText('allowed', 'Schváleno')
						->setCustomRender(function ($item) {
							if ($item['allowed'] === 0) {
								$i = Html::el('i', ['class' => 'glyphicon glyphicon-thumbs-down']);
								$el = Html::el('a', ['class' => 'btn btn-danger btn-xs btn-mini ajax'])
										->href($this->presenter->link("allowed!", $item['id']))
										->setHtml($i);
							} else {
								$i = Html::el('i', ['class' => 'glyphicon glyphicon-thumbs-up']);
								$el = Html::el('a', ['class' => 'btn btn-success btn-xs btn-mini ajax'])
										->href($this->presenter->link("allowed!", $item['id']))
										->setHtml($i);
							}
							return $el;
						})
				->cellPrototype->class[] = 'center';

		$grid->addColumnText('text', 'Text')
				->setCustomRender(function ($item) {
					$el = Html::el('span')->setText(Strings::substring($item['text'], 0, 80));
					return $el;
				});
		$grid->getColumn('text')->headerPrototype->style['width'] = '45%';

		$grid->addColumnText('page', 'Ke stránce')
				->setSortable()
				->setFilterText();

		$grid->addActionEvent('delete', '')
				->setCustomRender(function ($item) {
					$i = Html::el('i', ['class' => 'fa fa-trash']);
					$el = Html::el('a', ['class' => 'btn btn-default btn-xs btn-mini ajax'])
							->href($this->presenter->link("delete!", $item['id']))
							->setHtml($i);
					return $el;
				});

		$grid->setDefaultSort(['date' => 'DESC']);
		$grid->setDefaultPerPage(50);
		$grid->filterRenderType = $this->filterRenderType;
		$grid->setExport();

		return $grid;
	}

}
