<?php

namespace App\Model;

interface IGalleriesEntity 
{

   public function id();

   public function name();

   public function description();

   public function url();

}
