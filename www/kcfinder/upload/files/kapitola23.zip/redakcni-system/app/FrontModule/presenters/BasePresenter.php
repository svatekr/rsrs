<?php

namespace App\FrontModule\Presenters;

use App\FrontModule\Controls\MenuControl;
use App\FrontModule\Controls\ContactControl;
use App\FrontModule\Controls\NewsControl;
use App\FrontModule\Controls\SearchControl;
use Nette\Application\UI\Presenter;
use App\Model\PagesRepository;
use App\Model\NewsRepository;
use App\Model\SettingsRepository;
use App\Model\SettingsEntity;
use App\Forms\FormFactory;
use IPub\VisualPaginator\Components as VisualPaginator;
use Nette\Mail\SendmailMailer;
use Nette\Mail\SmtpMailer;

/**
 * Class BasePresenter
 * @package App\FrontModule\Presenters
 */
abstract class BasePresenter extends Presenter
{

	/** @var string @persistent */
	public $ajax = 'on';

	/** @var PagesRepository @inject */
	public $pagesRepository;

	/** @var NewsRepository @inject */
	public $newsRepository;

	/** @var FormFactory @inject */
	public $formFactory;

	/** @var SettingsRepository @inject */
	public $settingsRepository;

	/** @var SettingsEntity */
	protected $settings;

	public function startup() {
		parent::startup();
		$this->settings = $this->settingsRepository->getAll()->fetchPairs('field', 'value');
	}

	public function beforeRender() {
		parent::beforeRender();
		$this->getTemplate()->settings = $this->settings;
	}

	/**
	 * @return MenuControl
	 */
	protected function createComponentTopMenu() {
		$menu = new MenuControl($this->pagesRepository, 'topMenu');
		return $menu;
	}

	/**
	 * @return ContactControl
	 */
	protected function createComponentContactForm() {
		$control = new ContactControl($this->pagesRepository, $this->formFactory);
		$control->setSettings($this->settings);
		$control->setMailer($this->setMailer());
		return $control;
	}

	/**
	 * @return NewsControl
	 */
	public function createComponentNewsControl() {
		$control = new NewsControl($this->newsRepository);
		$control->setSettings($this->settings);
		return $control;
	}

	/**
	 * @return SearchControl
	 */
	public function createComponentSearchControl() {
		$control = new SearchControl($this->formFactory);
		return $control;
	}

	/**
	 * @return SendmailMailer|SmtpMailer
	 */
	protected function setMailer() {
		if ($this->settings['useMail']) {
			/** @var SendmailMailer mailer */
			$mailer = new SendmailMailer;
		} else {
			/** @var SmtpMailer mailer */
			$mailer = new SmtpMailer([
				'host' => $this->settings['smtpHost'],
				'username' => $this->settings['smtpUsername'],
				'password' => $this->settings['smtpPassword'],
				'secure' => $this->settings['smtpSecure'],
			]);
		}
		return $mailer;
	}

	/**
	 * Create items paginator
	 * @return VisualPaginator\Control
	 */
	protected function createComponentVisualPaginator() {
		$control = new VisualPaginator\Control;
		$control->setTemplateFile('bootstrap.latte');
		$control->enableAjax();
		$that = $this;
		$control->onShowPage[] = (function () use ($that) {
			if ($that->isAjax())
				$that->redrawControl();
		});

		return $control;
	}

}
