<?php

namespace App\Model;

class GalleriesRepository extends BaseRepository 
{

	/** @var GalleriesMapper */
	private $mapper;

	/**
	 * GalleriesRepository constructor.
	 * @param GalleriesMapper $mapper
	 */
	public function __construct(GalleriesMapper $mapper) {
		parent::__construct($mapper);
		$this->mapper = $mapper;
	}

	/**
	 * @param PagesEntity $page
	 */
	public function getAllGalleriesWithPicturesForPage(PagesEntity $page) {
		$galleries = [];
		$rows = $this->mapper->getAllGalleriesWithPicturesForPage($page);
		if($rows)
			foreach($rows as $row) {
				$galleries[$row['gallery_id']]['gallery'] = ['name' => $row['galleryName'], 'description' => $row['galleryDescription']];
				$galleries[$row['gallery_id']]['pictures'][] = $row;
			}
		return $galleries;
	}

}
