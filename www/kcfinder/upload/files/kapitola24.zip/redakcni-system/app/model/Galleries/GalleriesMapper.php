<?php

namespace App\Model;

use Dibi\Connection;

class GalleriesMapper extends BaseMapper
{

	/**
	 * GalleriesMapper constructor.
	 * @param Connection $db
	 */
	public function __construct(Connection $db) {
		parent::__construct($db);
	}

	/**
	 * @param PagesEntity $page
	 */
	public function getAllGalleriesWithPicturesForPage(PagesEntity $page) {
		return $this->db->select('g.name AS galleryName, g.description AS galleryDescription, p.*')
						->from($this->tableName)->as('g')
						->innerJoin('pictures')->as('p')->on('p.gallery_id = g.id')
						->where('g.id IN %in', json_decode($page->galleryIds()))
						->orderBy('g.id');
	}

}
