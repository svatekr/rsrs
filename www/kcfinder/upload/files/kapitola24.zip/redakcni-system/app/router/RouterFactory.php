<?php

namespace App;

use Nette;
use Nette\Application\Routers\RouteList;
use Nette\Application\Routers\Route;
use App\Model\PagesRepository;
use App\Model\NewsRepository;

/**
 * Class RouterFactory
 * @package App
 */
class RouterFactory {
	
	/** @var PagesRepository */
	private $pagesRepository;

	/** @var NewsRepository */
	private $newsRepository;

	public function __construct(PagesRepository $pagesRepository, NewsRepository $newsRepository) {
		$this->pagesRepository = $pagesRepository;
		$this->newsRepository = $newsRepository;
	}
	
	/**
	 * @return Nette\Application\IRouter
	 */
	public function createRouter() {
		$router = new RouteList();
		
		$router[] = $adminRouter = new RouteList('Admin');
		$adminRouter[] = new Route('[<locale=cs cs|en>/]admin/<presenter>/<action>', 'Pages:default');

		$router[] = $frontRouter = new RouteList('Front');
		
		$frontRouter[] = new PageRoute('[<locale=cs cs|en>/][stranky/]<id>', array(
			'id' => array(
				Route::FILTER_IN => function ($id) {
					if(is_numeric($id)) {
						return $id;
					} else {
						$page = $this->pagesRepository->getOneWhere(['url' => $id]);
						if($page === NULL)
							return NULL;
						return $page->id();
					}
				},
				Route::FILTER_OUT => function ($id) {
					if(!is_numeric($id)) {
						return $id;
					} else {
						$page = $this->pagesRepository->get($id);
						return $page->url();
					}
				}
			),
			'presenter' => 'Pages',
			'action' => 'view'
		));
			
		$frontRouter[] = new NewsRoute('[<locale=cs cs|en>/][novinky/]<id>', array(
			'id' => array(
				Route::FILTER_IN => function ($id) {
					if(is_numeric($id)) {
						return $id;
					} else {
						$page = $this->newsRepository->getOneWhere(['url' => $id]);
						if($page === NULL)
							return NULL;
						return $page->id();
					}
				},
				Route::FILTER_OUT => function ($id) {
					if(!is_numeric($id)) {
						return $id;
					} else {
						$page = $this->newsRepository->get($id);
						return $page->url();
					}
				}
			),
			'presenter' => 'News',
			'action' => 'view'
		));
		$frontRouter[] = new Route('[<locale=cs cs|en>/]<presenter>/<action>[/<id>]', 'Homepage:default');
		$frontRouter[] = new Route('[<locale=cs cs|en>/]index.php', 'Homepage:default', Route::ONE_WAY);
		return $router;
	}

}
