<?php

namespace App\Model;

/**
 * Class GalleriesRepository
 * @package App\Model
 */
class GalleriesRepository extends BaseRepository 
{

	/** @var GalleriesMapper */
	private $mapper;

	/**
	 * GalleriesRepository constructor.
	 * @param GalleriesMapper $mapper
	 */
	public function __construct(GalleriesMapper $mapper) {
		parent::__construct($mapper);
		$this->mapper = $mapper;
	}

}
