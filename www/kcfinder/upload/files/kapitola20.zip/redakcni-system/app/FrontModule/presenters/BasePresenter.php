<?php

namespace App\FrontModule\Presenters;

use App\FrontModule\Controls\MenuControl;
use App\FrontModule\Controls\ContactControl;
use App\FrontModule\Controls\NewsControl;
use Nette\Application\UI\Presenter;
use App\Model\PagesRepository;
use App\Model\NewsRepository;
use App\Forms\FormFactory;
use IPub\VisualPaginator\Components as VisualPaginator;

/**
 * Class BasePresenter
 * @package App\FrontModule\Presenters
 */
abstract class BasePresenter extends Presenter
{

	/** @var string @persistent */
	public $ajax = 'on';

	/** @var PagesRepository @inject */
	public $pagesRepository;

	/** @var NewsRepository @inject */
	public $newsRepository;

	/** @var FormFactory @inject */
	public $formFactory;

	public function startup() {
		parent::startup();
	}

	/**
	 * @return MenuControl
	 */
	protected function createComponentTopMenu() {
		$menu = new MenuControl($this->pagesRepository, 'topMenu');
		return $menu;
	}

	/**
	 * @return ContactControl
	 */
	protected function createComponentContactForm() {
		$control = new ContactControl($this->pagesRepository, $this->formFactory);
		return $control;
	}

	/**
	 * @return NewsControl
	 */
	public function createComponentNewsControl() {
		$control = new NewsControl($this->newsRepository);
		return $control;
	}

	/**
	 * Create items paginator
	 * @return VisualPaginator\Control
	 */
	protected function createComponentVisualPaginator() {
		$control = new VisualPaginator\Control;
		$control->setTemplateFile('bootstrap.latte');
		$control->enableAjax();
		$that = $this;
		$control->onShowPage[] = (function () use ($that) {
			if ($that->isAjax())
				$that->redrawControl();
		});

		return $control;
	}
}
