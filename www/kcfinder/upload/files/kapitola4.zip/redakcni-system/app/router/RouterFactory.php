<?php
 
namespace App;
 
use Nette;
use Nette\Application\Routers\RouteList;
use Nette\Application\Routers\Route;
 
class RouterFactory 
{
 
    /**
     * @return Nette\Application\IRouter
     */
    public static function createRouter() {
        $router = new RouteList;
        $router[] = $adminRouter = new RouteList('Admin');
        $adminRouter[] = new Route('[<locale=cs cs|en>/]admin/<presenter>/<action>[/<id>]', 'Pages:default');
 
        $router[] = $frontRouter = new RouteList('Front');
        $frontRouter[] = new Route('[<locale=cs cs|en>/]<presenter>/<action>[/<id>]', 'Homepage:default');
 
        $frontRouter[] = new Route('[<locale=cs cs|en>/]index.php', 'Homepage:default', Route::ONE_WAY);
        return $router;
    }
 
}