<?php

namespace App\FrontModule\Presenters;

/**
 * Class HomepagePresenter
 * @package App\FrontModule\Presenters
 */
class HomepagePresenter extends BasePresenter
{

	public function startup() {
		parent::startup();
	}

	/**
	 * Action Default
	 */
	public function actionDefault() {
		$page = $this->pagesRepository->getOneWhere(['onHomepage' => 1]);
		$this->getTemplate()->page = $page;
		$this->getTemplate()->title = ($page->title() > '' ? $page->title() : $page->name());
		$this->getTemplate()->description = $page->description() > '' ? $page->description() : $page->text();
		$this->getTemplate()->keywords = $page->keywords() > '' ? $page->keywords() : '';
	}
}