<?php

namespace App\FrontModule\Presenters;

use Nette\Application\UI\Presenter;
use App\Model\PagesRepository;
use App\Model\NewsRepository;

/**
 * Class BasePresenter
 * @package App\FrontModule\Presenters
 */
abstract class BasePresenter extends Presenter
{

	/** @var string @persistent */
	public $ajax = 'on';

	/** @var PagesRepository @inject */
	public $pagesRepository;

	/** @var NewsRepository @inject */
	public $newsRepository;

	public function startup() {
		parent::startup();
	}

}
