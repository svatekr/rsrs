<?php

namespace App\Model;

interface ISettingsEntity 
{

   public function id();

   public function field();

   public function value();

}
