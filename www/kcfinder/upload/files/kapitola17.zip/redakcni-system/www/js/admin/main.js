$(function () {

  //init grido
  $('.grido').grido({ajax: false});

});
