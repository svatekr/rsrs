$(function(){

    //init nette ajax
    $.nette.init();
	 
});

