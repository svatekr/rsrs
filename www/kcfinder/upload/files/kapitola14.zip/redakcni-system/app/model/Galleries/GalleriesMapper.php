<?php

namespace App\Model;
 
use Dibi\Connection;

/**
 * Class GalleriesMapper
 * @package App\Model
 */
class GalleriesMapper extends BaseMapper 
{
 
	/**
	 * GalleriesMapper constructor.
	 * @param Connection $db
	 */
	public function __construct(Connection $db) {
		parent::__construct($db);
	}
 
}
