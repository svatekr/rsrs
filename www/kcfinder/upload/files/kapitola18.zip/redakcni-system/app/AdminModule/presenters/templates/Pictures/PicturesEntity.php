<?php

namespace App\Model;

class PicturesEntity extends \Nette\Object implements IPicturesEntity
{

   private $id;
   private $name;
   private $description;
   private $file;
   private $order;
   private $gallery_id;

    public function id($id = null) {
        if (!is_null($id))
            $this->id = $id;
        return $this->id;
    }

    public function name($name = null) {
        if (!is_null($name))
            $this->name = $name;
        return $this->name;
    }

    public function description($description = null) {
        if (!is_null($description))
            $this->description = $description;
        return $this->description;
    }

    public function file($file = null) {
        if (!is_null($file))
            $this->file = $file;
        return $this->file;
    }

    public function order($order = null) {
        if (!is_null($order))
            $this->order = $order;
        return $this->order;
    }

    public function gallery_id($gallery_id = null) {
        if (!is_null($gallery_id))
            $this->gallery_id = $gallery_id;
        return $this->gallery_id;
    }

}
