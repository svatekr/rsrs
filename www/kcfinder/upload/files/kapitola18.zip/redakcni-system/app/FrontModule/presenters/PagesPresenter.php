<?php

namespace App\FrontModule\Presenters;

class PagesPresenter extends BasePresenter
{

	/** @var \App\Model\PagesEntity */
	private $page;

	public function startup() {
		parent::startup();
		$this->getTemplate()->addFilter('components', function ($text) {
			$presenter = $this;

			return preg_replace_callback('~\##(.*)\##~', function ($matches) use ($presenter) {
				$array = explode(", ", $matches[1]);
				$component = $array[0];
				ob_start();
				$component = $presenter->getComponent($component);
				unset($array[0]);
				if (count($array))
					$component->render($array);
				else
					$component->render();
				return ob_get_clean();
			}, $text);
		});
	}

	/**
	 * @param $id
	 */
	public function actionView($id) {
		$this->page = $this->pagesRepository->get($id);
		if ($this->page->secret() == 1 && !$this->user->isLoggedIn()) {
			$this->flashMessage('Ke stránce ' . (string) $this->page->name() . ' nemáte oprávnění', 'danger');
			$this->redirect('Homepage:default');
		}

		$this->getTemplate()->page = $this->page;
		$this->getTemplate()->title = ($this->page->title() > '' ? $this->page->title() : $this->page->name());
		$this->getTemplate()->description = $this->page->description() > '' ? $page->description() : $this->page->text();
		$this->getTemplate()->keywords = $this->page->keywords() > '' ? $this->page->keywords() : '';
	}

}
